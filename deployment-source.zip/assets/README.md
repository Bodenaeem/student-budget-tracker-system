The shared glass theme is in `glass-theme.css`. The Python app embeds the CSS and
background image, so no external requests are needed when the app runs.

The active background is `graphite-texture.png`, copied from the user's supplied
black texture screenshot. CSS overscan hides its thin white frame. Light mode
uses translucent white surfaces, silver borders, and a lighter blur so the
texture shows through. Dark mode keeps charcoal panels and light text.

`theme-sync.html` mirrors Streamlit's rendered light/dark color scheme onto the
document for the glass styles and native settings dialog. Streamlit remains
responsible for selecting and saving Light, Dark, or Use system setting.
The bridge replaces its observers on reruns. Chart labels use Streamlit's native
theme so they update with that same selection.

Previous optional background: `warm-interior.jpg`, a
[warm living room, via Unsplash](https://images.unsplash.com/photo-1600210492486-724fe5c67fb0).

"""Receipt extraction and local photo validation, without an OCR installation."""

import io
import subprocess
import unittest
from datetime import date
from decimal import Decimal
from unittest.mock import patch

from PIL import Image

from receipt_scanner import (
    MAX_UPLOAD_BYTES, ReceiptError, extract_receipt, prepare_image, recognize_text,
)


RECEIPT = """SUNRISE CAFE
18/11/2026 10:32
Coffee 12.00
Sandwich 18.00
Subtotal 30.00
SST 1.80
GRAND TOTAL RM 31.80
CASH 40.00
CHANGE 8.20
"""


def photo_bytes(color="white", fmt="PNG"):
    output = io.BytesIO()
    Image.new("RGB", (200, 300), color).save(output, format=fmt)
    return output.getvalue()


class ReceiptExtractionTests(unittest.TestCase):
    def test_extracts_final_paid_total_and_merchant_and_date(self):
        result = extract_receipt(RECEIPT)
        self.assertEqual(result.merchant, "SUNRISE CAFE")
        self.assertEqual(result.amount, Decimal("31.80"))
        self.assertEqual(result.transaction_date, date(2026, 11, 18))
        self.assertEqual(result.currency, "MYR")
        self.assertEqual(result.warnings, ())

    def test_prefers_grand_total_over_earlier_total(self):
        result = extract_receipt("SHOP\nTOTAL 20.00\nGRAND TOTAL RM 21.20")
        self.assertEqual(result.amount, Decimal("21.20"))
        self.assertTrue(any("Several totals" in note for note in result.warnings))

    def test_does_not_guess_total_from_item_price_or_subtotal(self):
        result = extract_receipt("SHOP\nItem RM 12.00\nSUB TOTAL 12.00\nCASH 20.00\nCHANGE 8.00")
        self.assertIsNone(result.amount)

    def test_supports_total_on_following_line(self):
        self.assertEqual(extract_receipt("SHOP\nAmount Due:\nRM 1,234.50").amount, Decimal("1234.50"))

    def test_does_not_take_next_item_as_total(self):
        self.assertIsNone(extract_receipt("SHOP\nTOTAL\nDiscount 5.00").amount)

    def test_supports_whole_ringgit_and_decimal_comma(self):
        self.assertEqual(extract_receipt("SHOP\nTOTAL RM 50").amount, Decimal("50"))
        self.assertEqual(extract_receipt("SHOP\nTOTAL RM 50,25").amount, Decimal("50.25"))

    def test_currency_without_space_before_amount(self):
        result = extract_receipt("SHOP\nTOTAL RM31.80")
        self.assertEqual(result.amount, Decimal("31.80"))
        self.assertEqual(result.currency, "MYR")

    def test_zero_negative_and_refund_totals_are_not_expenses(self):
        for token in ("0.00", "-5.00", "(5.00)"):
            with self.subTest(token=token):
                self.assertIsNone(extract_receipt(f"SHOP\nTOTAL RM {token}").amount)

    def test_malaysian_and_iso_dates(self):
        for token in ("18/11/2026", "18-11-26", "2026-11-18", "18 Nov 2026", "18 November 2026"):
            with self.subTest(token=token):
                self.assertEqual(extract_receipt(f"SHOP\n{token}").transaction_date, date(2026, 11, 18))

    def test_ambiguous_date_requires_review(self):
        result = extract_receipt("SHOP\n04/05/2026")
        self.assertEqual(result.transaction_date, date(2026, 5, 4))
        self.assertTrue(any("ambiguous" in note for note in result.warnings))

    def test_invalid_date_is_missing_and_expiry_is_ignored(self):
        self.assertIsNone(extract_receipt("SHOP\n31/02/2026").transaction_date)
        result = extract_receipt("SHOP\nExpiry: 10/10/2027\nDate 18/11/2026")
        self.assertEqual(result.transaction_date, date(2026, 11, 18))

    def test_missing_fields_are_not_filled_with_invented_values(self):
        result = extract_receipt("TAX INVOICE\nThank you")
        self.assertEqual(result.merchant, "")
        self.assertIsNone(result.amount)
        self.assertIsNone(result.transaction_date)
        self.assertGreaterEqual(len(result.warnings), 3)

    def test_merchant_can_start_with_a_number(self):
        self.assertEqual(extract_receipt("7-ELEVEN\n18/11/2026\nTOTAL 5.00").merchant, "7-ELEVEN")

    def test_foreign_and_unknown_currency_need_review(self):
        result = extract_receipt("SHOP\nTOTAL SGD 20.00")
        self.assertEqual(result.currency, "SGD")
        self.assertTrue(any("RM equivalent" in note for note in result.warnings))
        self.assertIsNone(extract_receipt("SHOP\nTOTAL $20.00").currency)

    def test_blank_text_is_an_actionable_error(self):
        with self.assertRaises(ReceiptError):
            extract_receipt(" \n ")


class ReceiptImageTests(unittest.TestCase):
    def test_normalizes_supported_formats_to_png(self):
        for fmt in ("JPEG", "PNG", "WEBP"):
            with self.subTest(fmt=fmt):
                result = prepare_image(photo_bytes(fmt=fmt))
                with Image.open(io.BytesIO(result)) as image:
                    self.assertEqual(image.format, "PNG")
                    self.assertEqual(image.mode, "RGB")

    def test_phone_orientation_is_applied_and_metadata_removed(self):
        image = Image.new("RGB", (200, 300), "white")
        exif = image.getexif()
        exif[274] = 6
        exif[315] = "Do not retain photo metadata"
        output = io.BytesIO()
        image.save(output, format="JPEG", exif=exif)
        with Image.open(io.BytesIO(prepare_image(output.getvalue()))) as result:
            self.assertEqual(result.size, (300, 200))
            self.assertFalse(result.getexif())

    def test_rejects_invalid_or_unsupported_content(self):
        for data in (b"not an image", b"", photo_bytes(fmt="GIF")):
            with self.subTest(size=len(data)), self.assertRaises(ReceiptError):
                prepare_image(data)

    def test_rejects_oversize_upload_and_pixel_dimensions(self):
        with self.assertRaisesRegex(ReceiptError, "10 MB"):
            prepare_image(b"x" * (MAX_UPLOAD_BYTES + 1))
        with patch("receipt_scanner.MAX_IMAGE_PIXELS", 10):
            with self.assertRaisesRegex(ReceiptError, "20 megapixels"):
                prepare_image(photo_bytes())

    def test_missing_engine_and_timeout_are_actionable(self):
        with patch("receipt_scanner.ocr_backend", return_value=None):
            with self.assertRaisesRegex(ReceiptError, "local OCR engine"):
                recognize_text(b"image")
        with patch("receipt_scanner.ocr_backend", return_value="Tesseract"), \
             patch("receipt_scanner.subprocess.run", side_effect=subprocess.TimeoutExpired("ocr", 45)):
            with self.assertRaisesRegex(ReceiptError, "took too long"):
                recognize_text(b"image")


if __name__ == "__main__":
    unittest.main()

"""Exercise expense confirmation in Streamlit with isolated records and a fake upload."""

import shutil
import sqlite3
import tempfile
import unittest
from datetime import date
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from receipt_scanner import ReceiptError
from test_receipt_scanner import RECEIPT, photo_bytes


HARNESS = """
import streamlit as st
from receipt_ui import render_receipt_scanner, clear_receipt_session
if 'saved_expenses' not in st.session_state:
    st.session_state.saved_expenses = []
if 'transactions' not in st.session_state:
    st.session_state.transactions = []
def save_expense(**expense):
    st.session_state.saved_expenses.append(expense)
render_receipt_scanner(st.session_state.transactions, save_expense)
"""


def widget(elements, label):
    return next(item for item in elements if item.label == label)


class ReceiptUITests(unittest.TestCase):
    def setUp(self):
        data = photo_bytes()
        self.upload = SimpleNamespace(size=len(data), getvalue=lambda: data)
        self.uploader = patch("receipt_ui.st.file_uploader", return_value=self.upload).start()
        self.ocr = patch("receipt_ui.recognize_text", return_value=RECEIPT).start()
        patch("receipt_ui.ocr_backend", return_value="Apple Vision").start()
        self.addCleanup(patch.stopall)
        self.app = AppTest.from_string(HARNESS, default_timeout=10).run()
        self.scan()

    def scan(self):
        widget(self.app.button, "Extract receipt details").click().run()
        self.assertFalse(list(self.app.exception))

    def confirm(self):
        widget(self.app.checkbox, "I checked the receipt and confirm these details and the amount in RM.").check()
        widget(self.app.button, "Confirm & save expense").click().run()

    def test_scan_does_not_save_and_prefills_review(self):
        self.assertEqual(self.app.session_state["saved_expenses"], [])
        self.assertEqual(widget(self.app.text_input, "Merchant").value, "SUNRISE CAFE")
        self.assertEqual(widget(self.app.number_input, "Receipt amount (RM)").value, 31.80)
        self.assertEqual(widget(self.app.date_input, "Receipt date").value, date(2026, 11, 18))

    def test_confirmation_required_and_edits_are_saved_once(self):
        widget(self.app.button, "Confirm & save expense").click().run()
        self.assertEqual(self.app.session_state["saved_expenses"], [])
        self.assertTrue(list(self.app.error))
        widget(self.app.text_input, "Merchant").set_value("Corrected cafe")
        widget(self.app.text_input, "Notes (optional)").set_value("Lunch")
        widget(self.app.number_input, "Receipt amount (RM)").set_value(32.50)
        widget(self.app.selectbox, "Expense category").set_value("Food")
        self.confirm()
        saved = self.app.session_state["saved_expenses"]
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0]["description"], "Corrected cafe — Lunch")
        self.assertEqual(saved[0]["amount"], 32.50)
        self.assertEqual(saved[0]["category"], "Food")
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.app.run()
        self.assertEqual(len(self.app.session_state["saved_expenses"]), 1)

    def test_missing_fields_remain_empty_until_corrected(self):
        self.ocr.return_value = "TAX INVOICE\nThank you"
        self.scan()
        self.assertEqual(widget(self.app.number_input, "Receipt amount (RM)").value, 0.0)
        self.assertIsNone(widget(self.app.date_input, "Receipt date").value)
        self.confirm()
        self.assertEqual(self.app.session_state["saved_expenses"], [])
        widget(self.app.text_input, "Merchant").set_value("New shop")
        widget(self.app.number_input, "Receipt amount (RM)").set_value(9.50)
        widget(self.app.date_input, "Receipt date").set_value(date(2026, 11, 17))
        self.confirm()
        self.assertEqual(len(self.app.session_state["saved_expenses"]), 1)

    def test_foreign_total_does_not_prefill_rm_amount(self):
        self.ocr.return_value = "FOREIGN SHOP\n18/11/2026\nTOTAL SGD 50.00"
        self.scan()
        self.assertEqual(widget(self.app.number_input, "Receipt amount (RM)").value, 0.0)
        self.assertTrue(any("RM equivalent" in note.value for note in self.app.warning))
        self.confirm()
        self.assertEqual(self.app.session_state["saved_expenses"], [])

    def test_duplicate_requires_separate_acknowledgment(self):
        self.app.session_state["transactions"] = [
            {"type": "Expense", "amount": 31.80, "date": "2026-11-18"},
        ]
        self.app.run()
        self.confirm()
        self.assertEqual(self.app.session_state["saved_expenses"], [])
        widget(self.app.checkbox, "I checked the existing expenses and want to save another.").check()
        self.confirm()
        self.assertEqual(len(self.app.session_state["saved_expenses"]), 1)

    def test_replacing_or_removing_upload_discards_previous_draft(self):
        data = photo_bytes("black")
        self.uploader.return_value = SimpleNamespace(size=len(data), getvalue=lambda: data)
        self.app.run()
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.assertFalse(list(self.app.text_input))
        self.scan()
        self.uploader.return_value = None
        self.app.run()
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.assertNotIn("receipt_image", self.app.session_state)

    def test_failed_rescan_cannot_save_previous_result(self):
        self.ocr.side_effect = ReceiptError("No text was found.")
        self.scan()
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.assertFalse(list(self.app.text_input))
        self.assertTrue(any("No text" in error.value for error in self.app.error))

    def test_discard_and_extraction_failure_clear_the_draft(self):
        with patch("receipt_ui.extract_receipt", side_effect=ReceiptError("Unreadable receipt")):
            self.scan()
        self.assertFalse(list(self.app.text_input))
        widget(self.app.button, "Discard receipt").click().run()
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.assertEqual(self.app.session_state["saved_expenses"], [])

    def test_save_failure_keeps_the_review_draft(self):
        failing = HARNESS.replace(
            "st.session_state.saved_expenses.append(expense)",
            "raise __import__('sqlite3').OperationalError('database is locked')",
        )
        self.app = AppTest.from_string(failing, default_timeout=10).run()
        self.scan()
        self.confirm()
        self.assertFalse(list(self.app.exception))
        self.assertIn("receipt_scan_result", self.app.session_state)
        self.assertEqual(widget(self.app.text_input, "Merchant").value, "SUNRISE CAFE")
        self.assertTrue(any("could not be saved" in error.value for error in self.app.error))

    def test_valid_image_can_be_reselected_after_oversize_upload(self):
        self.uploader.return_value = SimpleNamespace(size=11 * 1024 * 1024)
        self.app.run()
        self.assertNotIn("receipt_image", self.app.session_state)
        self.assertNotIn("receipt_scan_result", self.app.session_state)
        self.uploader.return_value = self.upload
        self.app.run()
        self.scan()
        self.assertIn("receipt_scan_result", self.app.session_state)

    def test_confirmed_expense_persists_in_isolated_app_database(self):
        source = Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory(prefix="budget-receipt-integration-") as folder:
            root = Path(folder)
            for name in ("Smart_Budget_Tracker_Professional.py", "budget_assistant.py",
                         "deployment_config.py", "receipt_scanner.py", "receipt_ui.py", "receipt_ocr.swift"):
                shutil.copy2(source / name, root / name)
            shutil.copytree(source / "assets", root / "assets")
            app = AppTest.from_file(str(root / "Smart_Budget_Tracker_Professional.py"), default_timeout=15)
            app.session_state["logged_in"] = True
            app.run()
            app.sidebar.radio[0].set_value("Add Expense").run()
            widget(app.radio, "Entry method").set_value("Scan receipt").run()
            widget(app.button, "Extract receipt details").click().run()
            with sqlite3.connect(root / "smart_budget_tracker.db") as connection:
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM transactions").fetchone()[0], 0)
            widget(app.selectbox, "Expense category").set_value("Food")
            widget(app.checkbox, "I checked the receipt and confirm these details and the amount in RM.").check()
            widget(app.button, "Confirm & save expense").click().run()
            self.assertFalse(list(app.exception))
            with sqlite3.connect(root / "smart_budget_tracker.db") as connection:
                rows = connection.execute("SELECT type, amount, category, description, date FROM transactions").fetchall()
                self.assertEqual(rows, [("Expense", 31.80, "Food", "SUNRISE CAFE", "2026-11-18")])
            app.sidebar.radio[0].set_value("Transaction History").run()
            self.assertFalse(list(app.exception))
            self.assertIn("SUNRISE CAFE", app.dataframe[0].value["Description"].tolist())
            app.sidebar.radio[0].set_value("Add Expense").run()
            widget(app.radio, "Entry method").set_value("Scan receipt").run()
            widget(app.button, "Extract receipt details").click().run()
            self.assertIn("receipt_scan_result", app.session_state)
            widget(app.button, "Sign out").click().run()
            self.assertFalse(app.session_state["logged_in"])
            self.assertNotIn("receipt_image", app.session_state)
            self.assertNotIn("receipt_scan_result", app.session_state)


if __name__ == "__main__":
    unittest.main()

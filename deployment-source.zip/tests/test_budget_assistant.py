"""Behavior checks for local finance calculations and conversation context."""

import unittest
from copy import deepcopy
from datetime import date
from decimal import Decimal

from budget_assistant import calculate, reply


class AssistantTests(unittest.TestCase):
    def setUp(self):
        self.today = date(2026, 11, 18)
        self.transactions = [
            {"type": "Income", "amount": 2000, "category": "Salary", "date": "2026-11-01"},
            {"type": "Expense", "amount": 120, "category": "Food", "date": "2026-11-02"},
            {"type": "Expense", "amount": 80, "category": "Bills", "date": "2026-11-03"},
            {"type": "Expense", "amount": 50, "category": "Food", "date": "2026-10-01"},
            {"type": "Expense", "amount": 25, "category": "Health", "date": "2026-09-01"},
        ]
        self.budgets = {"2026-11": 500}
        self.goals = [{"name": "Laptop", "target": 3000, "saved": 600}]
        self.context = {}

    def ask(self, question):
        return reply(question, self.transactions, self.budgets, self.goals,
                     self.today, self.context)

    def test_suggested_expense_question_does_not_match_greeting(self):
        answer = self.ask("How much did I spend this month?")
        self.assertIn("RM 200.00", answer)
        self.assertNotIn("Hi!", answer)

    def test_report_followup_retains_category_and_month(self):
        self.assertIn("RM 120.00", self.ask("How much did I spend on Food?"))
        answer = self.ask("And last month?")
        self.assertIn("October 2026", answer)
        self.assertIn("RM 50.00", answer)
        self.assertIn("RM 0.00", self.ask("What about September?"))

    def test_greetings_do_not_erase_pending_question(self):
        self.ask("I want to save 3000")
        self.ask("hi")
        self.assertIn("6 months", self.ask("500"))

    def test_savings_plan_followups(self):
        self.assertIn("RM 500.00 per month", self.ask("save RM 3,000 in 6 months"))
        self.assertIn("RM 400.00 per month", self.ask("already saved RM 600"))
        self.assertIn("8 months", self.ask("what if RM 300 per month"))
        self.assertIn("12 months", self.ask("200"))

    def test_savings_asks_for_missing_target_and_contribution(self):
        self.assertIn("target", self.ask("savings plan"))
        self.assertIn("per month", self.ask("3000"))
        self.assertIn("6 months", self.ask("500"))

    def test_named_goal_uses_saved_amount(self):
        self.assertIn("RM 400.00 per month", self.ask("save for Laptop in 6 months"))

    def test_savings_rounds_up_to_reach_target(self):
        self.assertIn("RM 33.34 per month", self.ask("save 100 in 3 months"))

    def test_shorthand_and_duration_followup(self):
        self.assertIn("RM 500.00 per month", self.ask("save 3k in 6 months"))
        self.assertIn("RM 250.00 per month", self.ask("what if 12 months"))

    def test_monthly_savings_is_not_mistaken_for_target(self):
        self.assertIn("target", self.ask("I can save 500 per month"))
        self.assertIn("6 months", self.ask("3000"))

    def test_savings_zero_and_negative_inputs(self):
        self.assertIn("greater than zero", self.ask("save 100 in 0 months"))
        self.assertIn("RM 50.00 per month", self.ask("2"))
        self.assertIn("cannot be negative", self.ask("already saved -10"))

    def test_loan_payment_and_followup(self):
        answer = self.ask("loan RM 10,000 at 6% over 3 years")
        self.assertIn("RM 304.22", answer)
        self.assertIn("RM 10,951.90", answer)
        self.assertIn("RM 277.78", self.ask("what if 0%"))

    def test_loan_collects_missing_values(self):
        self.assertIn("borrow", self.ask("loan calculator"))
        self.assertIn("annual interest", self.ask("10000"))
        self.assertIn("loan term", self.ask("6%"))
        self.assertIn("RM 443.21", self.ask("24 months"))

    def test_loan_rejects_invalid_term_and_rate(self):
        self.assertIn("1,200 months", self.ask("loan 10000 at -5% over 3 years"))
        self.assertIn("1,200 months", self.ask("loan 10000 at 5% over 200 years"))
        self.assertIn("whole-month", self.ask("loan 10000 at 5% over 2.5 months"))

    def test_affordability_uses_both_recorded_surplus_and_budget(self):
        self.assertIn("purchase cost", self.ask("Can I afford something?"))
        answer = self.ask("250")
        self.assertIn("RM 1,550.00", answer)
        self.assertIn("RM 50.00", answer)
        self.assertIn("not a check of available cash", answer)

    def test_supplied_income_and_expenses_do_not_use_saved_totals(self):
        answer = self.ask("I earn RM 3,000 and spend RM 2,000. How much is left?")
        self.assertIn("RM 1,000.00", answer)
        self.assertIn("not your saved transactions", answer)
        self.assertIn("RM 700.00", self.ask("what if I save 300"))
        self.assertIn("RM 450.00", self.ask("can I afford 250"))

    def test_cashflow_requests_missing_expenses(self):
        self.assertIn("total monthly expenses", self.ask("my income is 3000"))
        self.assertIn("RM 1,000.00", self.ask("2000"))
        self.assertIn("RM 500.00", self.ask("expenses are 2500"))

    def test_daily_allowance_includes_today(self):
        answer = self.ask("How much can I spend per day?")
        self.assertIn("13 days", answer)
        self.assertIn("RM 23.08", answer)
        self.assertIn("only applies to the current month", self.ask("and last month?"))

    def test_daily_allowance_missing_budget_and_overspend(self):
        self.budgets.clear()
        self.assertIn("Set a positive budget", self.ask("daily budget"))
        self.budgets["2026-11"] = 100
        self.assertIn("no positive daily allowance", self.ask("daily budget"))

    def test_month_comparison_and_non_adjacent_months(self):
        answer = self.ask("compare this month with last month")
        self.assertIn("November 2026 compared with October 2026", answer)
        self.assertIn("RM 150.00", answer)
        answer = self.ask("compare November with September")
        self.assertIn("November 2026 compared with September 2026", answer)
        self.assertIn("RM 175.00", answer)

    def test_january_previous_month(self):
        answer = reply("expenses last month", [], {}, [], date(2026, 1, 2), {})
        self.assertIn("December 2025", answer)

    def test_decimal_arithmetic_and_record_variables(self):
        self.assertIn("0.30", self.ask("calculate 0.1 + 0.2"))
        self.assertIn("900.00", self.ask("calculate (income - expenses) / 2"))
        self.assertIn("30.00", self.ask("15% of 200"))
        self.assertEqual(calculate("0.1 + 0.2", {}), Decimal("0.3"))

    def test_natural_arithmetic_questions(self):
        self.assertIn("400.00", self.ask("How much is 20% of my income?"))
        self.assertIn("1,800.00", self.ask("What is income - expenses?"))
        self.assertIn("30.00", self.ask("What is 10 + 20?"))

    def test_calculator_rejects_executable_input_and_resource_abuse(self):
        for expression in ("__import__('os').system('id')", "(1).__class__", "2 ** 1000000", "[1] * 1000000000", "9e999", "True + 1"):
            with self.subTest(expression=expression):
                with self.assertRaises((ValueError, ArithmeticError)):
                    calculate(expression, {})
        self.assertIn("divide by zero", self.ask("calculate 100 / 0"))

    def test_explicit_invalid_month(self):
        self.assertIn("01 to 12", self.ask("expenses in 2026-13"))

    def test_switching_topic_cancels_pending_calculator(self):
        self.ask("save 3000")
        self.assertIn("RM 200.00", self.ask("expenses this month"))
        self.assertNotIn("pending", self.context)

    def test_reset_clears_all_context(self):
        self.ask("save 3000 in 6 months")
        self.ask("start over")
        self.assertEqual(self.context, {})

    def test_inputs_are_never_mutated(self):
        before = deepcopy((self.transactions, self.budgets, self.goals))
        for question in ("overview", "save for Laptop in 6 months", "can I afford 250", "loan 10000 at 6% over 3 years"):
            self.ask(question)
        self.assertEqual((self.transactions, self.budgets, self.goals), before)


if __name__ == "__main__":
    unittest.main()
